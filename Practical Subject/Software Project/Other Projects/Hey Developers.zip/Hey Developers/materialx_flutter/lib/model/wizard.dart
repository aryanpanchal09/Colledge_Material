
import 'package:flutter/cupertino.dart';

class Wizard {

  String image;
  String background;
  String title;
  String brief;
  Color color;

}
