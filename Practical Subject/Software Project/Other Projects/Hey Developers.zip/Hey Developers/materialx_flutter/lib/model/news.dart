
class News {

  String image;
  String title;
  String subtitle;
  String date;

}
