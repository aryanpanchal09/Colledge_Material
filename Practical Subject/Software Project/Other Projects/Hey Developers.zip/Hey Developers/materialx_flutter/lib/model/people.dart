
class People {

  String image;
  String name;
  String email;
  bool section = false;


  People();

  People.section(this.name, this.section);

}
