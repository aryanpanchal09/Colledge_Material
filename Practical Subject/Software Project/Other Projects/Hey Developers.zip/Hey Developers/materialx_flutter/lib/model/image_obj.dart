
class ImageObj {

  String image;
  String name;
  String brief;
  int counter = -1;

}
