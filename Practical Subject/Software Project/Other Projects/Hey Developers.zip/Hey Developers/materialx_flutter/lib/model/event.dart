
class Event{

  String email;
  String name;
  String location;
  String from;
  String to;
  bool isAllDay;
  String timezone;

}