class MusicSong {

  String image;
  String title;
  String brief;

}