
class ShopProduct {

  String image;
  String title;
  String price;

}
