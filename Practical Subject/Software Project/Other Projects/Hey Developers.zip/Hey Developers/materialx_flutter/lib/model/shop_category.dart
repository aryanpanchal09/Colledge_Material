import 'package:flutter/cupertino.dart';

class ShopCategory {

  IconData icon;
  String image;
  String title;
  String brief;

}
